package backEnd;

public class Node  {
    huffmanNode data;
    Node next;

    public Node(huffmanNode data) {
        this.data = data;
    }


}
